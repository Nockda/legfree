package com.glasgow.tapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TappApplication {

    public static void main(String[] args) {
        SpringApplication.run(TappApplication.class, args);
    }

}
